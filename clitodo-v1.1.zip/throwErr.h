// RaddedMC's quick error thrower v1.0 -- throwErr.h

void throwErr(std::string reason, int code);
void throwErr(std::string reason);
#define ITS_THE_USERS_FAULT 5