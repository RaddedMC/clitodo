// James N's command-line todo list app! -- globals.h

extern std::string ** list;
extern int num_pairs;